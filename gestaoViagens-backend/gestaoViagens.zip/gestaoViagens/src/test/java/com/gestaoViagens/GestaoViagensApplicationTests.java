package com.gestaoViagens;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestaoViagensApplicationTests {

	@Test
	void contextLoads() {
	}

}
